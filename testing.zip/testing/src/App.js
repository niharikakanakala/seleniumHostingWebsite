import React from 'react';
import { Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import CRUDPage from './components/CRUDPage';
import SearchPage from './components/SearchPage';
import SortPage from './components/SortPage';
import ListPage from './components/ListPage';
import DetailPage from './components/DetailPage';
import StatusCodesPage from './components/StatusCodePage';
import Hover from './components/Hover';
import DynamicContent from './components/DynamicContent';
import Alerts from './components/Alerts';
import Counter from './components/Counter';
import './styles/App.css';

const App = () => {
  // Function to check if the static content flag is present in URL
  const checkStaticContent = () => {
    const searchParams = new URLSearchParams(window.location.search);
    return searchParams.get('with_content') === 'static';
  };

  return (
    <div className="App">
      <NavBar />
      <div className="content">
        <Routes>
          <Route path="/" element={<CRUDPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/sort" element={<SortPage />} />
          <Route path="/list" element={<ListPage />} />
          <Route path="/detail/:id" element={<DetailPage />} />
          <Route path="/status-codes" element={<StatusCodesPage />} />
          <Route path="/status-codes/:code" element={<StatusCodesPage />} />
          <Route path="/hover" element={<Hover />} />
          <Route path="/counter" element={<Counter />} />
          <Route
            path="/dynamic-content"
            element={<DynamicContent withStaticContent={checkStaticContent()} />} // Ensure props are passed correctly
          />
          <Route path="/alerts" element={<Alerts />} />
        </Routes>
      </div>
    </div>
  );
};

export default App;
