import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/ListPage.css';

const ListPage = () => {
  const items = [
    {
      id: 1,
      name: 'Article 1',
      description: 'This is a detailed description of Article 1. It includes an overview of the topic, key points discussed, and any other relevant information.',
    },
    {
      id: 2,
      name: 'Article 2',
      description: 'This is a detailed description of Article 2. It includes an overview of the topic, key points discussed, and any other relevant information.',
    },
    {
      id: 3,
      name: 'Article 3',
      description: 'This is a detailed description of Article 3. It includes an overview of the topic, key points discussed, and any other relevant information.',
    },
    {
      id: 4,
      name: 'Article 4',
      description: 'This is a detailed description of Article 4. It includes an overview of the topic, key points discussed, and any other relevant information.',
    },
    {
      id: 5,
      name: 'Article 5',
      description: 'This is a detailed description of Article 5. It includes an overview of the topic, key points discussed, and any other relevant information.',
    },
  ];

  return (
    <div className="list-page">
      <h1>List of Articles</h1>
      <ul>
        {items.map(item => (
          <li key={item.id}>
            <Link to={`/detail/${item.id}`}>
              <h2>{item.name}</h2>
              <p>{item.description}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListPage;
