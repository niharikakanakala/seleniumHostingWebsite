import React, { useState } from 'react';
import '../styles/SearchPage.css';

const SearchPage = () => {
    const [items] = useState([
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' },
      { id: 3, name: 'Item 3' },
    ]);
    const [search, setSearch] = useState('');
  
    const filteredItems = items.filter(item => 
      item.name.toLowerCase().includes(search.toLowerCase())
    );
  
    return (
      <div className="search-page">
        <h1>Search Operations</h1>
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search items"
        />
        <ul>
          {filteredItems.map(item => (
            <li key={item.id}>{item.name}</li>
          ))}
        </ul>
      </div>
    );
  };
  
export default SearchPage;
