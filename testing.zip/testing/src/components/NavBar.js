import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/NavBar.css'; // Ensure correct path to CSS file

const NavBar = () => {
  return (
    <nav className="navbar vertical-nav"> {/* Apply both classes */}
      <ul>
        <li>
          <Link to="/">CRUD</Link>
        </li>
        <li>
          <Link to="/search">Search</Link>
        </li>
        <li>
          <Link to="/sort">Sort</Link>
        </li>
        <li>
          <Link to="/list">List</Link>
        </li>
        <li>
          <Link to="/status-codes">Status Codes</Link>
        </li>
        <li>
          <Link to="/hover">Hover</Link>
        </li>
        <li>
          <Link to="/dynamic-content">Dynamic Content</Link>
        </li>
        <li>
            <Link to="/alerts">Alerts</Link>
        </li>
        <li>
           <Link to="/counter">Counter</Link>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;
