import React, { useState } from 'react';
import '../styles/CRUDPage.css';

const CRUDPage = () => {
  const [items, setItems] = useState([]);
  const [name, setName] = useState('');

  const addItem = () => {
    setItems([...items, { id: Date.now(), name }]);
    setName('');
  };

  const deleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  return (
    <div className="crud-page">
      <h1>CRUD Operations</h1>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter item name"
      />
      <button onClick={addItem}>Add Item</button>
      <ul>
        {items.map(item => (
          <li key={item.id}>
            {item.name} <button onClick={() => deleteItem(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CRUDPage;
