import React, { useState } from 'react';
import '../styles/Hover.css';

const Hover = () => {
  const [users] = useState([
    { id: 1, name: 'User 1', profile: 'Profile 1' },
    { id: 2, name: 'User 2', profile: 'Profile 2' },
    { id: 3, name: 'User 3', profile: 'Profile 3' },
  ]);

  const [activeUser, setActiveUser] = useState(null);

  const handleMouseEnter = (user) => {
    setActiveUser(user);
  };

  const handleMouseLeave = () => {
    setActiveUser(null);
  };

  const handleViewProfile = (profile) => {
    alert(`View Profile: ${profile}`);
  };

  return (
    <div className="hover-container">
      <h1>Hover Component</h1>
      <div className="hover-images">
        {users.map((user) => (
          <div
            key={user.id}
            className="hover-image"
            onMouseEnter={() => handleMouseEnter(user)}
            onMouseLeave={handleMouseLeave}
          >
            <img
              src={`https://picsum.photos/id/${user.id}/200/200`}
              alt={`User ${user.id}`}
              className="hover-image-img"
            />
            {activeUser && activeUser.id === user.id && (
              <div className="hover-details">
                <h3>{user.name}</h3>
                <p>{user.profile}</p>
                <button
                  className="view-profile-button"
                  onClick={() => handleViewProfile(user.profile)}
                >
                  View Profile
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Hover;
