import React, { useState } from 'react';
import '../styles/Alerts.css'; // Import CSS file for styling

const Alerts = () => {
  const [alertResult, setAlertResult] = useState('');

  const handleClick = (type) => {
    let resultMessage = '';
    switch (type) {
      case 'alert':
        alert('You successfully clicked an alert');
        resultMessage = 'You successfully clicked an alert';
        break;
      case 'confirm':
        if (window.confirm('Are you sure you want to confirm?')) {
          alert('You confirmed!');
          resultMessage = 'You confirmed!';
        } else {
          alert('You canceled.');
          resultMessage = 'You canceled.';
        }
        break;
      case 'prompt':
        const response = prompt('Enter something:');
        if (response !== null) {
          alert(`You entered: ${response}`);
          resultMessage = `You entered: ${response}`;
        } else {
          alert('You canceled.');
          resultMessage = 'You canceled.';
        }
        break;
      default:
        break;
    }
    setAlertResult(resultMessage);
  };

  return (
    <div className="alerts-container">
      <h1>JavaScript Alerts</h1>
      <p>
        Here are some examples of different JavaScript alerts which can be troublesome for automation.
      </p>
      <hr />
      <div className="buttons-container">
        <button onClick={() => handleClick('alert')}>Click for JS Alert</button>
        <button onClick={() => handleClick('confirm')}>Click for JS Confirm</button>
        <button onClick={() => handleClick('prompt')}>Click for JS Prompt</button>
      </div>
      {alertResult && (
        <div className="result-container">
          <h2>Result:</h2>
          <p>{alertResult}</p>
        </div>
      )}
    </div>
  );
};

export default Alerts;
