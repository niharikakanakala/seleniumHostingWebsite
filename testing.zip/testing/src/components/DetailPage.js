import React from 'react';
import { useParams } from 'react-router-dom';
import '../styles/DetailPage.css';

const DetailPage = () => {
  const { id } = useParams();
  const articles = {
    1: {
      title: 'Article 1',
      content: 'This is a detailed content of Article 1. It includes an in-depth discussion of the topic, various perspectives, and any other relevant information.',
    },
    2: {
      title: 'Article 2',
      content: 'This is a detailed content of Article 2. It includes an in-depth discussion of the topic, various perspectives, and any other relevant information.',
    },
    3: {
      title: 'Article 3',
      content: 'This is a detailed content of Article 3. It includes an in-depth discussion of the topic, various perspectives, and any other relevant information.',
    },
    4: {
      title: 'Article 4',
      content: 'This is a detailed content of Article 4. It includes an in-depth discussion of the topic, various perspectives, and any other relevant information.',
    },
    5: {
      title: 'Article 5',
      content: 'This is a detailed content of Article 5. It includes an in-depth discussion of the topic, various perspectives, and any other relevant information.',
},
};

const article = articles[id];

return (
    <div className="detail-page">
        <h1>{article.title}</h1>
        <p>{article.content}</p>
    </div>
    );
};

export default DetailPage;
