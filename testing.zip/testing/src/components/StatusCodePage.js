import React from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import "../styles/StatusCodePage.css";

const StatusCodesPage = () => {
  const navigate = useNavigate();
  const { code } = useParams();
  const statusCodes = [
    { code: 200, description: 'OK: The request has succeeded.' },
    { code: 301, description: 'Moved Permanently: The resource has been moved to a new URL.' },
    { code: 404, description: 'Not Found: The server can not find the requested resource.' },
    { code: 500, description: 'Internal Server Error: The server encountered an error.' },
  ];

  const currentStatus = statusCodes.find(status => status.code === parseInt(code));

  const handleGoBack = () => {
    navigate('/status-codes');
  };

  if (code && currentStatus) {
    return (
      <div className="status-codes-page">
        <h1>Status Codes</h1>
        <p>This page returned a {currentStatus.code} status code.</p>
        <p>
          For a definition and common list of HTTP status codes,{' '}
          <button className="link-button" onClick={handleGoBack}>go here</button>.
        </p>
      </div>
    );
  }

  return (
    <div className="status-codes-page">
      <h1>Status Codes</h1>
      <p>
        HTTP status codes are a standard set of numbers used to communicate from a web server to your browser to indicate the outcome of the request being made (e.g., Success, Redirection, Client Error, Server Error). 
       
      </p>
      <ul>
        {statusCodes.map(status => (
          <li key={status.code}>
            <Link to={`/status-codes/${status.code}`}>{status.code}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StatusCodesPage;
