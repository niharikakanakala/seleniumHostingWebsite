import React, { useState } from 'react';
import "../styles/DynamicContent.css";

const DynamicContent = () => {
  const [randomText, setRandomText] = useState(generateRandomText());

  function generateRandomText() {
    // Replace this with logic to generate random text
    const texts = [
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
      "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    ];
    return texts[Math.floor(Math.random() * texts.length)];
  }

  const handleRandomTextClick = () => {
    setRandomText(generateRandomText());
  };

  return (
    <div className="dynamic-content">
      <h1>Dynamic Content</h1>
      <p>
        This example demonstrates the ever-evolving nature of content by loading new text on each page refresh.
      </p>
      <p>
        To make some of the content static append ?with_content=static or click <button onClick={handleRandomTextClick}>here</button>.
      </p>
      <hr />
      <p>Accusantium eius ut architecto neque vel voluptatem vel nam eos minus ullam dolores voluptates enim sed voluptatem rerum qui sapiente nesciunt aspernatur et accusamus laboriosam culpa tenetur hic aut placeat error autem qui sunt.</p>
     <p>Omnis fugiat porro vero quas tempora quis eveniet ab officia cupiditate culpa repellat debitis itaque possimus odit dolorum et iste quibusdam quis dicta autem sint vel quo vel consequuntur dolorem nihil neque sunt aperiam blanditiis.</p>
      <p>{randomText}</p>
    </div>
  );
};

export default DynamicContent;
