import React, { useState } from 'react';
import '../styles/SortPage.css';

const SortPage = () => {
    const [items] = useState([
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' },
      { id: 3, name: 'Item 3' },
    ]);
    const [sortOrder, setSortOrder] = useState('asc');
  
    const sortedItems = [...items].sort((a, b) => {
      if (sortOrder === 'asc') return a.name.localeCompare(b.name);
      return b.name.localeCompare(a.name);
    });
  
    return (
      <div className="sort-page">
        <h1>Sort Operations</h1>
        <button onClick={() => setSortOrder('asc')}>Sort Ascending</button>
        <button onClick={() => setSortOrder('desc')}>Sort Descending</button>
        <ul>
          {sortedItems.map(item => (
            <li key={item.id}>{item.name}</li>
          ))}
        </ul>
      </div>
    );
  };
export default SortPage;